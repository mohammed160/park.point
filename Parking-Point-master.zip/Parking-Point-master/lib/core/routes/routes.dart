const homeView = "/homeView";
const searchView = "/searchView";
const timerView = "/timerView";
const homeNavbar =  "/homeNavbar";
const signInView = "/signInView";
const signUpView =  "/signUpView";
const onBoarding =  "/onBoarding";
const splashView =  "/";